﻿//-----------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace ETIC2
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for <c>MainWindow.xaml</c>
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow"/> class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }
    }
}
