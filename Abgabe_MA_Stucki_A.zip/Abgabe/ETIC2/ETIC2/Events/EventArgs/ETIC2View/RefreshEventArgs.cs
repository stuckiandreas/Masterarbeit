﻿//-----------------------------------------------------------------------
// <copyright file="RefreshEventArgs.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ETIC2.Events.EventArgs.ETIC2View
{
    /// <summary>
    /// Event to update the DatabaseDataGrid view
    /// </summary>
    public class RefreshEventArgs : System.EventArgs
    {
    }
}
