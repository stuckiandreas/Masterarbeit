﻿//-----------------------------------------------------------------------
// <copyright file="WorkspaceViewModel.xaml.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ETIC2.Views
{
    using System.Windows.Controls;
    using ViewModels;

    /// <summary>
    /// Interaction logic for WorkspaceView.xaml
    /// </summary>
    public partial class WorkspaceView : UserControl
    {
        public WorkspaceView()
        {
            this.InitializeComponent();
        }
    }
}
