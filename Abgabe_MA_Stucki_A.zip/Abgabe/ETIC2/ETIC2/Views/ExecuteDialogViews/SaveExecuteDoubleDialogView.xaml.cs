﻿//-----------------------------------------------------------------------
// <copyright file="SaveExecuteDoubleDialogView.xaml.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ETIC2.Views.ExecuteDialogViews
{
    using System.Windows.Controls;

    /// <summary>
    /// View which has two text input controls.
    /// </summary>
    public partial class SaveExecuteDoubleDialogView : UserControl
    {
        public SaveExecuteDoubleDialogView()
        {
            this.InitializeComponent();
        }
    }
}
