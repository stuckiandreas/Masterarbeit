﻿//-----------------------------------------------------------------------
// <copyright file="StatusbarView.xaml.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ETIC2.Views.StatusbarViews
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for StatusbarView.xaml
    /// </summary>
    public partial class StatusbarView : UserControl
    {
        public StatusbarView()
        {
            this.InitializeComponent();
        }
    }
}
