﻿//-----------------------------------------------------------------------
// <copyright file="MenuView.xaml.cs" company="VAT Vakuumventile AG">
//     Copyright (c) 2017 . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ETIC2.Views.MenuViews
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MenuView.xaml
    /// </summary>
    public partial class MenuView : UserControl
    {
        public MenuView()
        {
            this.InitializeComponent();
        }
    }
}
